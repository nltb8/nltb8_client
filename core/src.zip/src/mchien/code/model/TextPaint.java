package mchien.code.model;

public class TextPaint {
   public byte idColor = 0;
   public byte idColorSub = 0;
   public String text = "";
   public String subString = "";
}
