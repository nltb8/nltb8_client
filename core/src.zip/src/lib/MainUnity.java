package lib;

public class MainUnity {
   public static boolean isPC;
   public static boolean isAndroid;
   public static boolean isJava = false;
   public static boolean isLowGraphics;
}
