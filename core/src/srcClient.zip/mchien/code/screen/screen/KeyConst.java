package mchien.code.screen.screen;

public class KeyConst {
   public static final int UP = -1;
   public static final int DOWN = -2;
   public static final int LEFT = -3;
   public static final int RIGHT = -4;
   public static final int FIRE = -5;
   public static final int SOFT_LEFT = -6;
   public static final int SOFT_RIGHT = -7;
   public static final int CLEAR = -8;
}
