package mchien.code.model;

public class ServerInfo {
   public String tile;
   public String[] info;
}
