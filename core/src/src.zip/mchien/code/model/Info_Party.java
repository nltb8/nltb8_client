package mchien.code.model;

public class Info_Party {
   public String nameMember;
   public String nameMap;
   public boolean isMaster;
   public short menberLv;
   public byte menberArena;
}
