package mchien.code.model;

public class PotionTemplate {
   public short price;
   public short recovered;

   public PotionTemplate(short price, short recovered) {
      this.price = price;
      this.recovered = recovered;
   }
}
