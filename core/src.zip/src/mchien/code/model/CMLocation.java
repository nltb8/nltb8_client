package mchien.code.model;

public class CMLocation {
   public int toM;
   public int toX;
   public int toY;
   public int xtile;
   public int ytile;

   public CMLocation(int toM, int toX, int toY) {
      this.toM = toM;
      this.toX = toX;
      this.toY = toY;
   }
}
