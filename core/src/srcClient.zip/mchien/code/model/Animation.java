package mchien.code.model;

public class Animation {
   public byte[] frame;

   public Animation(byte[] frame) {
      this.frame = frame;
   }
}
