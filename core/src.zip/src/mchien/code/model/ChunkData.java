package mchien.code.model;

public class ChunkData {
   public byte index;
   public byte dx;
   public byte dy;
}
