package mchien.code.model;

import lib.mGraphics;

public interface IActionListener {
   void perform(int var1, Object var2);

   void paint(mGraphics var1, int var2, int var3, int var4, Object var5);
}
