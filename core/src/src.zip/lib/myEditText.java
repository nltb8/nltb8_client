package lib;

public class myEditText {
   public static boolean isVisible;

   public void end() {
   }
}
