package lib2;

public enum TouchScreenKeyboardType {
   Default,
   ASCIICapable,
   NumberPad;
}
