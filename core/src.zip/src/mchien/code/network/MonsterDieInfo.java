package mchien.code.network;

public class MonsterDieInfo {
   public short attacker;
   public short attacked;
   public byte skillID;
   public ItemDropInfo[] itemDrop;
   public int hpLost;
   public byte effect;
   public byte x2 = 1;
   public byte buffAttack = -1;
   public byte level = 0;
}
