package mchien.code.effect.new_skill;

public class StarSkillnormal {
}
