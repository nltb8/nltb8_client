package mchien.code.model;

import mchien.code.screen.screen.ScreenTeam;
import lib.mGraphics;
import lib.mVector;

public class ShopOnline extends ScreenTeam implements IActionListener {
   public static mVector ALL_ITEM;
   public static int[] indexPage;
   public static short[] nPage;
   public static long money;

   public void paint(mGraphics g, int idAction, int x, int y, Object paint) {
   }

   public void perform(int idAction, Object p) {
   }

   public void onItemInfo() {
   }

   public void setItemInventory() {
   }
}
