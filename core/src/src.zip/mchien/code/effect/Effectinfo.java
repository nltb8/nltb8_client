package mchien.code.effect;

public class Effectinfo {
   public short id;
   public byte poss;
}
