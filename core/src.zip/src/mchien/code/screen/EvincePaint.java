package mchien.code.screen;

public class EvincePaint {
   public static EvincePaint[] arr;
   public int id;
   public EvinceInfo[] infos;
}
