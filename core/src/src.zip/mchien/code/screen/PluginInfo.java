package mchien.code.screen;

public class PluginInfo {
   public EvincePaint effectPaint;
   public int frame;
   public int dx;
   public int dy;
}
