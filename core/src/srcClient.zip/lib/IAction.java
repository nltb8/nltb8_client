package lib;

public class IAction {
}
