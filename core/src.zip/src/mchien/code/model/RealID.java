package mchien.code.model;

public class RealID {
   public short realID;
   public short ID;
   public int price;
   public short number;

   public RealID() {
   }

   public RealID(short read) {
      this.realID = read;
   }
}
