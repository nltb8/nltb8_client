package mchien.code.network;

public class ItemDropInfo {
   public byte itemCatagory;
   public short itemTemplateID;
   public short itemID;
   public short x;
   public short y;
   public byte colorname;
}
