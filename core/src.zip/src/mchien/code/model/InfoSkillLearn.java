package mchien.code.model;

public class InfoSkillLearn {
   public String name = "";
   public String decript = "";
   public byte idSkill = -1;
   public byte charClass = -1;
   public int price = 0;
}
