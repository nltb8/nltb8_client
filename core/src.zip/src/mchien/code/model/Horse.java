package mchien.code.model;

import lib.mGraphics;

public class Horse {
   public int idImg;

   public Horse(int idimg) {
      this.idImg = idimg;
   }

   public void paint(mGraphics g, int x, int y) {
   }
}
