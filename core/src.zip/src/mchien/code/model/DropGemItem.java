package mchien.code.model;

public class DropGemItem extends Dropable {
}
