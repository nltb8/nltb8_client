package lib;

public class Main {
   public static boolean isPC;
   public static boolean isAndroid;
   public static boolean isJava = false;
}
