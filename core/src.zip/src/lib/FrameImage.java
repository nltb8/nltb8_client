package lib;

public class FrameImage {
}
