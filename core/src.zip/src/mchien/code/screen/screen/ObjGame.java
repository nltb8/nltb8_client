package mchien.code.screen.screen;

import mchien.code.model.mCommand;
import lib.mGraphics;

public class ObjGame {
   public boolean isTfield;
   public int x;
   public int y;
   public int width;
   public int height;
   public mCommand acPopup;
   public String title = "";

   public void paint(mGraphics g) {
   }

   public void update() {
   }

   public void updateKey() {
   }

   public boolean keyPressed(int keyCode) {
      return false;
   }
}
