package mchien.code.model;

public class SkillBossTemplate {
   public int idSkill = -1;
   public byte[][] arrayAnimAttackUp;
   public byte[][] arrayAnimAttackDown;
}
