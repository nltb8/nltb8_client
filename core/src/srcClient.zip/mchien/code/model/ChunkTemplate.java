package mchien.code.model;

public class ChunkTemplate {
   public short id;
   public byte rotate;
   public byte paintId;
   public byte dx;
   public byte dy;
}
