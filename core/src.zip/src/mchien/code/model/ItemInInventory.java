package mchien.code.model;

public class ItemInInventory extends ObjCharWearing {
}
