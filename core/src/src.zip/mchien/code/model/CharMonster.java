package mchien.code.model;

public class CharMonster extends Char {
   public CharMonster() {
      this.catagory = 1;
      this.height = 60;
   }
}
