package mchien.code.model;

import lib.mVector;

public class ItemHair {
   public String[] nameTile;
   public byte[] idColorTile;
   public mVector ListNameOption = new mVector();
   public mVector ListIDColorOption = new mVector();
}
