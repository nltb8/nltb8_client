package mchien.code.model.arrow;

import mchien.code.model.Actor;
import lib.mVector;

public class SubArrow {
   public Actor from;
   public mVector to = new mVector();
   public mVector power = new mVector();
   public mVector hp = new mVector();
   public int ideff;
   public int imgIndex;
}
