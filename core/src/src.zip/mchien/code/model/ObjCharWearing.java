package mchien.code.model;

public class ObjCharWearing {
   public void showInfo() {
   }

   public boolean isItem() {
      return false;
   }

   public boolean isPet() {
      return false;
   }

   public int getType() {
      return 0;
   }

   public short getStyle() {
      return 0;
   }
}
