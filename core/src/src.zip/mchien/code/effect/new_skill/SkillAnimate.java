package mchien.code.effect.new_skill;

public abstract class SkillAnimate {
   int x;
   int y;
   int attackPower;
   public int dam;
}
