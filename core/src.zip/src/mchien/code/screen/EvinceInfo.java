package mchien.code.screen;

public class EvinceInfo {
   public int id;
   public int dx;
   public int dy;
   public byte rotate;
}
