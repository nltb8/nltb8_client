package mchien.code.model;

public class ChunkDemo {
   public int iconBegin;
   public ChunkTemplate[] templates;
}
