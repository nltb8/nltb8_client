package mchien.code.screen;

public class SkillInfo {
   public int frame;
   public int dartPaintId;
   public int dartDx;
   public int dartDy;
}
