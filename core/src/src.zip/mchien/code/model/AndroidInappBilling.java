package mchien.code.model;

public class AndroidInappBilling {
   public static AndroidInappBilling instance() {
      return null;
   }

   public void consumePurchase(String productId) {
   }
}
