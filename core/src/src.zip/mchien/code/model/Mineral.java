package mchien.code.model;

public class Mineral {
   public String name;
   public short idTemplate;
   public byte number;
}
