package lib;

public class Cout {
   public static void println(int a) {
   }

   public static void println(String a) {
   }

   public static void println(boolean a) {
   }

   public static void Debug(String a) {
   }
}
