package mchien.code.model;

public class GemTemplate {
}
