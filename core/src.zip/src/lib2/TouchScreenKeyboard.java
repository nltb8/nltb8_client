package lib2;

public class TouchScreenKeyboard {
   public static boolean hideInput;
   public static boolean visible;
   public boolean done;
   public boolean active;
   public String text;

   public static TouchScreenKeyboard Open(String text, TouchScreenKeyboardType t, boolean b1, boolean b2, boolean type, boolean b3, String caption) {
      return null;
   }

   public static void Clear() {
   }
}
