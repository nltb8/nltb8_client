package mchien.code.screen.screen;

import mchien.code.model.IActionListener;
import lib.mGraphics;

public class PauseMenu extends ScreenTeam implements IActionListener {
   public void perform(int idAction, Object p) {
   }

   public void paint(mGraphics g, int idAction, int x, int y, Object paint) {
   }
}
