package mchien.code.screen.screen;

import mchien.code.model.AnimalInfo;
import mchien.code.model.GemTemp;
import mchien.code.model.Item;
import mchien.code.model.ItemTemplate;
import mchien.code.model.RealID;
import lib.mVector;

public class SetInfoData {
   public byte[][] byteArr;
   public boolean iss;
   public boolean isSkill;
   public RealID real;
   public int xx;
   public int yy;
   public int index;
   public int index1;
   public Item itemInven1;
   public short pl;
   public mVector vt;
   public Object mobj;
   public GemTemp gemTempItem;
   public GemTemp gemTempItem2;
   public AnimalInfo itemAnimal;
   public String str;
   public String decript;
   public byte numbyte;
   public byte mainSub;
   public byte type;
   public byte typePotion;
   public ItemTemplate itemTemp;
   public short rID;
   public short itemType;
   public int num;
   public int cat;
   public int ID;
   public int idIcon;
   public int stateQuest;
   public int idQuest;
}
