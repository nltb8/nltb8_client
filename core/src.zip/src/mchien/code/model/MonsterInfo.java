package mchien.code.model;

public class MonsterInfo {
   public short id;
   public short x;
   public short y;
   public short lv;
   public long hp;
   public long maxhp;
   public int timeLive;
   public int charid = -1;
   public byte monster_type;
   public byte he;
   public byte colorName;
   public byte totalWay = 2;
   public short default_x;
   public short default_y;
   public short dyPaintPk;
   public String name;
   public boolean canFocus;
   public boolean beFire;
   public String nameTieu = "";
}
