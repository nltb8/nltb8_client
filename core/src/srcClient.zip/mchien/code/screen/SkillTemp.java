package mchien.code.screen;

public class SkillTemp {
   public SkillInfo[] infos;
   public PluginPaint pluginPaint;
}
